const lib = {
  version: "1.3.2",
};

export default lib;
