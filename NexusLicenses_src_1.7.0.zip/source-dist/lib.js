const lib = {
  version: "1.7.0",
};

export default lib;
