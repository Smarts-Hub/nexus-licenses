const lib = {
  version: "1.6.0",
};

export default lib;
